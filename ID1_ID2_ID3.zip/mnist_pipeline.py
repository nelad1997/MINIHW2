from __future__ import annotations

from pathlib import Path

import numpy as np
from PIL import Image, ImageOps


IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".bmp", ".gif", ".tif", ".tiff"}


def iter_image_paths(data_dir: Path) -> list[Path]:
    return sorted(
        path
        for path in data_dir.iterdir()
        if path.is_file() and path.suffix.lower() in IMAGE_EXTENSIONS
    )


def load_image_as_vector(image_path: Path) -> np.ndarray:
    image = Image.open(image_path).convert("L")
    image_array = np.asarray(image, dtype=np.uint8)

    border_pixels = np.concatenate(
        [
            image_array[0, :],
            image_array[-1, :],
            image_array[:, 0],
            image_array[:, -1],
        ]
    )

    # MNIST is usually bright foreground on a dark background.
    # If the border is bright, we likely received a black digit on white background.
    if border_pixels.mean() > 127:
        image = ImageOps.invert(image)

    image = ImageOps.autocontrast(image)

    if image.size != (28, 28):
        image = image.resize((28, 28), Image.Resampling.BILINEAR)

    return (np.asarray(image, dtype=np.float32) / 255.0).reshape(1, -1)


def prediction_output_path(source_path: Path, prediction: int, output_dir: Path) -> Path:
    return output_dir / f"{source_path.stem}_{prediction}{source_path.suffix.lower()}"
