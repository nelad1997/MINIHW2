from __future__ import annotations

import argparse
import logging
import shutil
from pathlib import Path

import joblib

from mnist_pipeline import IMAGE_EXTENSIONS, iter_image_paths, load_image_as_vector, prediction_output_path


def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )


def main() -> None:
    configure_logging()
    parser = argparse.ArgumentParser(
        description="Run MNIST inference on images from Data/ and write renamed copies to Predictions/."
    )
    parser.add_argument(
        "--model-path",
        type=Path,
        default=Path("artifacts") / "mnist_linear_svc.joblib",
        help="Path to the trained model artifact.",
    )
    parser.add_argument(
        "--data-dir",
        type=Path,
        default=Path("Data"),
        help="Directory with images to classify.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("Predictions"),
        help="Directory where renamed prediction files will be stored.",
    )
    args = parser.parse_args()
    logging.info("Inference configuration: model_path=%s, data_dir=%s, output_dir=%s", args.model_path, args.data_dir, args.output_dir)

    if not args.model_path.is_file():
        raise FileNotFoundError(f"Model file was not found: {args.model_path}")
    if not args.data_dir.is_dir():
        raise FileNotFoundError(f"Data directory was not found: {args.data_dir}")

    image_paths = iter_image_paths(args.data_dir)
    if not image_paths:
        raise FileNotFoundError(f"No image files were found in {args.data_dir}")
    logging.info("Found %s images for inference", len(image_paths))

    args.output_dir.mkdir(parents=True, exist_ok=True)
    logging.info("Ensured output directory exists: %s", args.output_dir)

    removed_files = 0
    for existing_path in args.output_dir.iterdir():
        if existing_path.is_file() and existing_path.suffix.lower() in IMAGE_EXTENSIONS:
            existing_path.unlink()
            removed_files += 1
    if removed_files:
        logging.info("Removed %s existing prediction image(s) from %s", removed_files, args.output_dir)

    logging.info("Loading trained model")
    model = joblib.load(args.model_path)
    logging.info("Model loaded successfully")
    for image_path in image_paths:
        logging.info("Running prediction for %s", image_path.name)
        prediction = int(model.predict(load_image_as_vector(image_path))[0])
        output_path = prediction_output_path(image_path, prediction, args.output_dir)
        shutil.copy2(image_path, output_path)
        logging.info("Saved prediction output: %s -> %s", image_path.name, output_path.name)

    logging.info("Inference completed successfully")


if __name__ == "__main__":
    main()
