from __future__ import annotations

import argparse
import logging
from pathlib import Path
from urllib.request import urlretrieve

import joblib
import numpy as np
from sklearn.svm import LinearSVC


MNIST_URL = "https://storage.googleapis.com/tensorflow/tf-keras-datasets/mnist.npz"


def configure_logging() -> None:
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s | %(levelname)s | %(message)s",
        datefmt="%H:%M:%S",
    )


def download_mnist(dataset_path: Path) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    dataset_path.parent.mkdir(parents=True, exist_ok=True)
    if not dataset_path.exists():
        logging.info("Downloading MNIST to %s", dataset_path)
        urlretrieve(MNIST_URL, dataset_path)
        logging.info("Finished downloading MNIST")
    else:
        logging.info("Using cached MNIST dataset from %s", dataset_path)

    with np.load(dataset_path) as data:
        x_train = data["x_train"]
        y_train = data["y_train"]
        x_test = data["x_test"]
        y_test = data["y_test"]

    logging.info(
        "Loaded dataset: x_train=%s, y_train=%s, x_test=%s, y_test=%s",
        x_train.shape,
        y_train.shape,
        x_test.shape,
        y_test.shape,
    )
    return x_train, y_train, x_test, y_test


def build_model(random_state: int) -> LinearSVC:
    return LinearSVC(dual=False, max_iter=5_000, random_state=random_state)


def main() -> None:
    configure_logging()
    parser = argparse.ArgumentParser(description="Train a baseline SVM-style MNIST classifier.")
    parser.add_argument(
        "--dataset-path",
        type=Path,
        default=Path("assets") / "mnist.npz",
        help="Where to cache the downloaded MNIST dataset.",
    )
    parser.add_argument(
        "--model-path",
        type=Path,
        default=Path("artifacts") / "mnist_linear_svc.joblib",
        help="Where to save the trained model.",
    )
    parser.add_argument(
        "--train-size",
        type=int,
        default=12_000,
        help="How many MNIST training samples to use.",
    )
    parser.add_argument(
        "--random-state",
        type=int,
        default=42,
        help="Seed for reproducible training.",
    )
    args = parser.parse_args()
    logging.info("Training configuration: dataset_path=%s, model_path=%s, train_size=%s, random_state=%s", args.dataset_path, args.model_path, args.train_size, args.random_state)

    x_train, y_train, x_test, y_test = download_mnist(args.dataset_path)
    logging.info("Preparing training and test arrays")
    x_train = x_train[: args.train_size].reshape(args.train_size, -1).astype(np.float32) / 255.0
    y_train = y_train[: args.train_size].astype(np.int64)
    x_test = x_test.reshape(len(x_test), -1).astype(np.float32) / 255.0
    y_test = y_test.astype(np.int64)
    logging.info("Prepared arrays: x_train=%s, y_train=%s, x_test=%s, y_test=%s", x_train.shape, y_train.shape, x_test.shape, y_test.shape)

    model = build_model(args.random_state)
    logging.info("Starting model training on %s MNIST samples", len(x_train))
    model.fit(x_train, y_train)
    logging.info("Model training completed")
    accuracy = model.score(x_test, y_test)
    logging.info("Test accuracy: %.4f", accuracy)

    args.model_path.parent.mkdir(parents=True, exist_ok=True)
    logging.info("Saving trained model to %s", args.model_path)
    joblib.dump(model, args.model_path)
    logging.info("Saved trained model successfully")


if __name__ == "__main__":
    main()
